import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.*;
import java.util.ArrayList;

public class FirstMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    private ArrayList<String> stopWords = new ArrayList<>();
    Text k = new Text();

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(new File("/opt/install/stopwords.txt"))));
        String word = "";
        while ((word=reader.readLine())!=null){
            stopWords.add(word);
        }
        reader.close();
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        boolean flag = true;
        String line = value.toString();
        String[] fields = line.split("\t");
        if(fields.length == 4) {  //获取一行中第4列所有单词
            String[] words = fields[3].split(" ");
            for (String word : words) {
                word = word.trim();
                if (!word.matches("^[0-9]*$")) {  //不是数字的单词
                    for (String stopWord : stopWords){
                        if (word.equals(stopWord.trim())){  //包含stopwords的单词则置flag为false
                            flag = false;
                        }
                    }
                    if(flag){
                        k.set(word);
                        context.write(k, new IntWritable(1));
                    }
                }
            }
        }
    }
}
