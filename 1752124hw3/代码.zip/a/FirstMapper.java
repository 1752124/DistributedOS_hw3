package com.mapreduce.a;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class FirstMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    Text k = new Text();
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] fields = value.toString().split("\t");
        //获取第4列所有单词
        if(fields.length == 4){
            String[] words = fields[3].split(" ");
            for (String word : words){
                word = word.trim();
                //如果单词不是数字计数
                if(!word.matches("^[0-9]*$")) {
                    k.set(word);
                    context.write(k,new IntWritable(1));
                }
            }
        }
    }
}
