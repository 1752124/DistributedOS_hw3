package com.mapreduce.a;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class SecondReducer extends Reducer<MyIntWritable, Text, Text, MyIntWritable> {
    private int i = 0;
    @Override
    protected void reduce(MyIntWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

        for (Text value : values){
            if(i<100) {
                context.write(value, key);
            }
            i++;
        }
    }
}
