import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class SecondDriver {
    public static void main(String[] args) throws Exception{
        //1 获取 configuration配置
        Configuration configuration = new Configuration();
        //2 通过Configuration 获取job
        Job job = Job.getInstance(configuration);
        //3 设置驱动类
        job.setJarByClass(SecondDriver.class);
        //4 设置mapper和reducer
        job.setMapperClass(SecondMapper.class);
        job.setReducerClass(SecondReducer.class);
        //5 设置mapper输出类型
        job.setMapOutputKeyClass(MyIntWritable.class);
        job.setMapOutputValueClass(Text.class);
        //6 设置最终输出类型
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(MyIntWritable.class);
        //7 设置输入输出文件路径
        FileInputFormat.setInputPaths(job,new Path(args[0]));
        FileOutputFormat.setOutputPath(job,new Path(args[1]));
        //8 提交
        System.exit(job.waitForCompletion(true) ? 0 : 1);

    }
}
